import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h2>Things I need to do:</h2>
      <p>*Learn React</p>
      <p>*Climb Mt. Everest</p>
      <p>*Run a marathon</p>
      <p>*Feed the dogs</p>
    </div>
  );
}

export default App;
